
function startNewGame() {
    //Delete blocks from previous game
  component = Qt.createComponent("Field.qml");
  object = component.createObject(page);
    }
